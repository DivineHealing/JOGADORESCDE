from django.apps import AppConfig


class TelaPersonagemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tela_personagem'
