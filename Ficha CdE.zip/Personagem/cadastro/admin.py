from django.contrib import admin
from .models import Maestria

# Register your models here.
admin.site.register(Maestria)