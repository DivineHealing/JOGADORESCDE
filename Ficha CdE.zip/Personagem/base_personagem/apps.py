from django.apps import AppConfig


class BasePersonagemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'base_personagem'
