from django.contrib import admin
from .models import Base_personagem

admin.site.register(Base_personagem)