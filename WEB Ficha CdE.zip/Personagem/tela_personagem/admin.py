from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Tela_personagem)
admin.site.register(Character_attribute)
admin.site.register(Character_effects)