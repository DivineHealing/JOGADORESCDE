from django.contrib import admin
from .models import Conjunto

admin.site.register(Conjunto)