from django.contrib import admin
from .models import Arma

admin.site.register(Arma)