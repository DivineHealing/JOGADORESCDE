from django.contrib import admin
from .models import Habilidade

admin.site.register(Habilidade)